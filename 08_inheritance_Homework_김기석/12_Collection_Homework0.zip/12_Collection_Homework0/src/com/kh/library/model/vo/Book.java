package com.kh.library.model.vo;

public class Book {
	private String bNo;
	private String title;
	private String author;
	private String publisher;
	private int price;
	private String description;
	
	public Book() {}
	
	// 단축키로 생성해보기
	
	
	
	
	

}
