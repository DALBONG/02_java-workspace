package com.kh.library.model.vo;

// Book 상속받아서 작성
public class Magazine {
	private int year;
	private int month;
	
	public Magazine() {}

	// 단축키로 생성해보기
	
	
}
